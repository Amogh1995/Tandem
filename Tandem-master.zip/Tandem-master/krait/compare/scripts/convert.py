import os
def pdf2jpginput(filename):
    basepath=os.path.dirname(os.path.abspath('.'))
    print basepath
    from pdf2jpg import pdf2jpg
    print filename
    inputpath = filename
    outputpath = basepath+"/krait/media/files/inputjpg"
    # To convert single page
    result = pdf2jpg.convert_pdf2jpg(inputpath, outputpath, pages="ALL")
    print(result)

def pdf2jpgoutput(filename):
    basepath=os.path.dirname(os.path.abspath('.'))
    print basepath
    from pdf2jpg import pdf2jpg
    print filename
    inputpath = filename
    outputpath = basepath+"/krait/media/files/outputjpg"
    # To convert single page
    result = pdf2jpg.convert_pdf2jpg(inputpath, outputpath, pages="ALL")
    print(result)
