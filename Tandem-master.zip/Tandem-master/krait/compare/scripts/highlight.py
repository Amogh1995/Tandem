import numpy as np
import imutils
import cv2 as cv
import os

def highlightinput(l1,l2):
    import copy
    basepath=os.path.dirname(os.path.abspath('.'))
    #basepath+"/krait/krait/media/files/inputjpg/"
    print basepath +"@@@@@"
    lst= copy.deepcopy(l1)
    img = cv.imread(basepath+'/compare/scripts/input-1.png')
    #img = cv.rectangle(img, (1667,285), (1746,342), (255,0,0), 4)
    for a in lst:
        print a[0][0],a[0][1],a[2][0],a[2][1]
        p1=a[0][0]-10
        p2=a[0][1]-10
        p3=a[2][0]+10
        p4=a[2][1]+10
        img = cv.rectangle(img, (p1,p2), (p3,p4), (255,0,0), 4)
        cv.imwrite('Draw01.jpg',img)
        #print a[1][0][0],a[1][0][1],a[1][2][0],a[1][2][1]
    image = cv.imread("Draw01.jpg")
    rotated = imutils.rotate_bound(image, 90)
    cv.imwrite('Draw021.jpg',rotated)
    lst2= copy.deepcopy(l2)
    img = cv.imread('Draw021.jpg')
    for a in lst2:
        print a[0][0],a[0][1],a[2][0],a[2][1]
        p1=a[0][0]-10
        p2=a[0][1]-10
        p3=a[2][0]+10
        p4=a[2][1]+10
        img = cv.rectangle(img, (p1,p2), (p3,p4), (255,0,0), 4)
        cv.imwrite('Draw021.jpg',img)
    image = cv.imread("Draw021.jpg")
    rotated = imutils.rotate_bound(image, -90)
    cv.imwrite('Finalinput.jpg',rotated)

def highlightoutput(l1,l2):
    import copy
    lst= copy.deepcopy(l1)
    basepath=os.path.dirname(os.path.abspath('.'))
    img = cv.imread(basepath+'/compare/scripts/output-1.png')
    #img = cv.rectangle(img, (1667,285), (1746,342), (255,0,0), 4)
    for a in lst:
        print a[0][0],a[0][1],a[2][0],a[2][1]
        p1=a[0][0]-10
        p2=a[0][1]-10
        p3=a[2][0]+10
        p4=a[2][1]+10
        img = cv.rectangle(img, (p1,p2), (p3,p4), (255,0,0), 4)
        cv.imwrite('Drawout01.jpg',img)
        #print a[1][0][0],a[1][0][1],a[1][2][0],a[1][2][1]
    image = cv.imread("Drawout01.jpg")
    rotated = imutils.rotate_bound(image, 90)
    cv.imwrite('Drawout021.jpg',rotated)
    lst2= copy.deepcopy(l2)
    img = cv.imread('Drawout021.jpg')
    for a in lst2:
        print a[0][0],a[0][1],a[2][0],a[2][1]
        p1=a[0][0]-10
        p2=a[0][1]-10
        p3=a[2][0]+10
        p4=a[2][1]+10
        img = cv.rectangle(img, (p1,p2), (p3,p4), (255,0,0), 4)
        cv.imwrite('Drawout021.jpg',img)
    image = cv.imread("Drawout021.jpg")
    rotated = imutils.rotate_bound(image, -90)
    cv.imwrite('Finaloutput.jpg',rotated)


