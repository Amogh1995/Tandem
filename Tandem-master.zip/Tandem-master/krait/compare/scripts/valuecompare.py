def comparelists(l1,l2):
    
    import copy
    tst1=copy.deepcopy(l1)
    tst2=copy.deepcopy(l2)
    #print tst1
    for a in l1:
        
        for b in l2:
            if a[0]==b[0]:
                
                   if  ((a[1][0][0]-100.0)<= b[1][0][0] <= (a[1][0][0]+100.0)) and ((a[1][0][1]-100.0)<= b[1][0][1] <= (a[1][0][1]+100.0)) and  ((a[1][1][0]-100.0)<= b[1][1][0] <= (a[1][1][0]+100.0)) and ((a[1][1][1]-100.0)<= b[1][1][1] <= (a[1][1][1]+100.0)):
                   
                       tst1.remove(a)
                       tst2.remove(b)

                 
    hightlightin=[]
    hightlightout=[]

    for a in tst1:    
        hightlightin.append(a[1])
    for a in tst2:    
        hightlightout.append(a[1])
    
    return hightlightin,hightlightout
   